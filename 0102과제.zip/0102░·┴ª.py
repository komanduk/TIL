# 1
# number_ = (int(input("숫자를 입력해주세요 :")))
# print(number_ + 10)

# 2
# food = (str(input("좋아하는 음식을 입력해주세요 :")))
# print("좋아하는 음식: " + food)

# 3
# name = (str(input("이름을 입력해주세요 :")))
# year = (int(input("태어난 년도를 입력해주세요 :")))
# sum = 2024 - (year)
# print("저의 이름은 " + name + " 이고," +" 올해나이는" + str(sum) + "세입니다")

# 4
# first = (str(input("첫 번째 문장을 입력해주세요")))
# second = (str(input("두 번째 문장을입력해주세요")))
# sum = (first + second)
# print(sum)

# 5
# number__ = (int(input("정수형 숫자를 입력해주세요")))
# print(-number__)

# 6
# first = (int(input("첫 번째 정수형 숫자를 입력해주세요")))
# second = (int(input("두 번째 정수형 숫자를 입력해주세요")))
# sum = first + second
# subtrack = first - second
# multiply = first * second
# blahblah = first // second
# blahblah2 = first % second
# print(sum, subtrack, multiply, blahblah, blahblah2)

# 7
# first = (int(input("첫 번째 정수형 숫자를 입력해주세요")))
# second = (int(input("두 번째 정수형 숫자를 입력해주세요")))
# third = (int(input("세 번째 정수형 숫자를 입력해주세요")))

# sum = ((first + second + third)/ 3)

# print(sum)

# 8
# one = (int(input("첫 번째 정수형 숫자를 입력해주세요")))
# two = (int(input("두 번째 정수형 숫자를 입력해주세요")))
# three = (int(input("세 번째 정수형 숫자를 입력해주세요")))
# four = (int(input("네 번째 정수형 숫자를 입력해주세요")))
# five = (int(input("다섯 번째 정수형 숫자를 입력해주세요")))

# array = [one, two, three, four, five]

# print(array)

# 9
# string = (str(input("문자열을 입력해주세요")))
# number___ = (int(input("정수형 숫자를 입력해주세요")))

# sum = (string * number___)

# print(sum)

# 10

# one = (int(input("첫 번째 정수형 숫자를 입력해주세요")))
# print(one)
# two = (int(input("두 번째 정수형 숫자를 입력해주세요")))
# print(one + two)
# sum = one + two
# three = (int(input("세 번째 정수형 숫자를 입력해주세요")))
# print(sum + three)
# four = (int(input("네 번째 정수형 숫자를입력해주세요")))
# print(sum + three + four)
# five = (int(input("다섯 번째 정수형숫자를 입력해주세요")))
# print(sum + three + four + five)
