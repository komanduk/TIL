# 1

# 2
# i = 0
# number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# for i in number_list:
#     if i %2 == 0:
#       i = i + 1
# print(i)

# 3
# i = 0
# result = 0
# number_list = [-1, -2, -3, -4, -5]
# for i in number_list:
#     result = result + i
#     i = i + 1
#     print(result)
# print(result)

# 4
# number_list = [2, 4, 6]
# i = 0
# n = 0
# sum = 0
# for i in number_list:
#     sum = sum + i
#     n +=1

# print(sum, n, number_list, sum/n)
# number_list = [2,4,6]
# sum=0
# cnt=0

# for elements in number_list:
#     sum+=elements
#     cnt+=1
# print(sum/cnt)

#5
# m = 1
# number_list = [-1, -2, 3,]
# for n in number_list:
#     m = m * n
#     n += 1
#     print(m)
# print(m)

# 6
# tmp = 0
# number_list = [1, 2, 7, 4, 5, 10]
# for n in number_list:
#     if tmp<n:
#         tmp=n
#         print(tmp)
# print(tmp)

# 7
# tmp = 1
# number_list = [12, 2, 4, 5, 0]
# for n in number_list:
#     if tmp>n:
#         tmp=n
#         print(tmp)
# print(tmp)

# number_list = [1, 2, 3, 4, 5, -1]
# number_list.sort()
# print(number_list[0])
