# 1
# n = int(input("정수를 입력하세요"))
# print(n > 0)

# 2 
# n1 = int(input("첫 번째 정수를입력하세요"))
# n2 = int(input("두 번째 정수를입력하세요"))
# if n1 > n2:
#    print("Ture")
# else :
#        print("False")

# 3
# n = int(input("정수를 입력하세요"))
# if 1 < n:
#     print(n < 10)
# elif n < 10:
#     print(n > 10)

# 4
# n = int(input("정수를 입력하세요"))
# result = n %2 ==1
# if n < 0:
#     print(False)
# else:
#    print(result<1)

# 5
#n = int(input("정수를 입력하세요"))
#if n > 100:
#    print("에러")
#elif n < (-n + 1):
#    print("에러")
#else:
#     n <= 100
#     print("합격")

# 6
# n = str(input("문자열을 입력하세요"))
# for c in range(len(n)):
#     print(n[-c-1])

# 7
# n1 = int(input("첫 번쨰 정수를 입력하세요"))
# n2 = int(input("두 번째 정수를 입력하세요"))
# if n1 == n2:
#    print(False)
# elif n1>n2:
#     for element in range(n1, n2+1):
#         print(element)
# else:
#      n1<n2
#for element in range(n2, n1+1):
#         print(element)



